# Prism Paradox

A ghost-and-pyramid math adventure game starring Prism Paradox, a character created by Leo.

## Play
Open `index.html` in any web browser. No install needed.

## Files
- `index.html` — the whole game (HTML, CSS and JavaScript in one file)
- `leo-drawing.jpg` — Leo's original drawing, shown on the page

## Put it online with GitHub Pages
1. Upload both files to the root of a GitHub repository.
2. Go to **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**, pick `main` and `/ (root)`, then **Save**.
4. After a minute or two, the game is live at `https://<username>.github.io/<repo-name>/`.

## Controls
Arrow keys or tap to walk · Space shoot + spar · M power boost (math) · L lightning · S supernova · D dance · G ghost hands · B power safe belt
